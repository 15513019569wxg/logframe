create definer = root@`%` view myv1 as
select `myemployees`.`employees`.`last_name` AS `last_name`, `myemployees`.`employees`.`email` AS `email`
from `myemployees`.`employees`;

