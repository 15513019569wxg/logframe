create
    definer = root@`%` procedure myp4(IN username varchar(20), IN password varchar(20))
begin
    declare ret int default 1;
    select count(*) into ret from girls.admin
    where admin.username = username and admin.password = password;
    select if(ret > 0, 'success', 'fail');
end;

