create definer = root@`%` view myv2 as
select 'join' AS `name`;

