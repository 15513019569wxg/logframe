create
    definer = root@`%` procedure testOut(IN beautyName varchar(20), OUT boyName varchar(20))
begin
    select bo.boyname into boyname from girls.boys bo
    right join girls.beauty b on b.boyfriend_id = bo.id
    where b.name = beautyName;
end;

